DECLARE
message varchar2(20):='Hello World!';
BEGIN
dbms_output.put_line(message);
END;
/


